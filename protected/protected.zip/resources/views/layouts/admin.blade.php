
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<title>Inventory</title>

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="{{ asset('assets/css/icons/icomoon/styles.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('assets/css/bootstrap.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('assets/css/core.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('assets/css/components.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('assets/css/colors.css') }}" rel="stylesheet" type="text/css">
	@stack('css')
	<!-- /global stylesheets -->

	<!-- Core JS files -->
	<script type="text/javascript" src="{{ asset('assets/js/plugins/loaders/pace.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/js/core/libraries/jquery.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/js/core/libraries/bootstrap.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/js/plugins/loaders/blockui.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/nicescroll.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/drilldown.js') }}"></script>
	<script type="text/javascript" src="{{ asset('js/axios.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('js/vue.js') }}"></script>
	<script type="text/javascript" src="{{ url('phpjs') }}"></script>
	@stack('sec-js')
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript">
		const URL = "{{ url('/') }}/",
		CURRENT = "{{ request()->url() }}",
		TOKEN = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

		function logoutSession(event) {
			event.preventDefault();
			axios.post(URL+'logout');
			setTimeout(function () {
				location.reload();
			}, 300);
		}
	</script>
	<script type="text/javascript" src="{{ asset('assets/js/core/app.js') }}"></script>
	@stack('js')
	<!-- /theme JS files -->

</head>

<body>
	<!-- Main navbar -->
	<div class="navbar navbar-inverse" {{-- style="background-color: #F4511E; border-top: 0px; --}}">
		<div class="navbar-header">
			<a class="navbar-brand" href="index.html"><img src="{{ asset('assets/images/logo_light.png') }}" alt=""></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">

			<p class="navbar-text"><span class="label bg-success-400">Online</span></p>

			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown language-switch">
					<a class="dropdown-toggle" data-toggle="dropdown">
						@if(auth()->user()->language == 'en') 
							<img src="{{ asset('assets/images/flags/gb.png') }}" class="position-left" alt=""> English <span class="caret"></span>
						@else 
							<img src="{{ asset('assets/images/flags/jp.png') }}" class="position-left" alt=""> 日本語 <span class="caret"></span>
						@endif
					</a>

					<ul class="dropdown-menu">
						<li {!! auth()->user()->language === 'en' ? 'class="active"' : '' !!}><a href="{{ url('language_en') }}" class="english"><img src="{{ asset('assets/images/flags/gb.png') }}" alt=""> English</a></li>
						<li {!! auth()->user()->language === 'jp' ? 'class="active"' : '' !!}><a href="{{ url('language_jp') }}" class="espana"><img src="{{ asset('assets/images/flags/jp.png') }}" alt=""> 日本語</a></li>
					</ul>
				</li>

				<li class="dropdown dropdown-user">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<img src="{{ asset('assets/images/placeholder.jpg') }}" alt="">
						<span>{{ auth()->user()->fullname }}</span>
						<i class="caret"></i>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a href="#" onclick="logoutSession(event)"><i class="icon-switch2"></i>@lang('trans.logout')</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Second navbar -->
	<div class="navbar navbar-default" id="navbar-second">
		<ul class="nav navbar-nav no-border visible-xs-block">
			<li><a class="text-center collapsed" data-toggle="collapse" data-target="#navbar-second-toggle"><i class="icon-menu7"></i></a></li>
		</ul>

		<div class="navbar-collapse collapse" id="navbar-second-toggle">
			<ul class="nav navbar-nav">
				
				<li {!! request()->is('dashboard') || request()->is('home') || request()->is('/') ? 'class="active"' : '' !!}><a href="{{ url('dashboard') }}"><i class="icon-display4 position-left"></i> @lang('trans.dashboard')</a></li>
				
				@if (auth()->user()->role == 1)
				<li {!! request()->is('stock_master') ? 'class="active"' : '' !!}><a href="{{ url('stock_master') }}"><i class="icon-cube3 position-left"></i> @lang('trans.stock_master')</a></li>
				<li {!! request()->is('bs_stock') ? 'class="active"' : '' !!}><a href="{{ url('bs_stock') }}"><i class="icon-stack3 position-left"></i> @lang('trans.bs_stock')</a></li>
				@endif

				<li {!! request()->is('stock') ? 'class="active"' : '' !!}><a href="{{ url('stock') }}"><i class="icon-cube position-left"></i> @lang('trans.stock')</a></li>

				@if (auth()->user()->role == 1)
				<li {!! request()->is('shift') ? 'class="active"' : '' !!}><a href="{{ url('shift') }}"><i class="icon-file-text position-left"></i> @lang('trans.shift')</a></li>

				@else
				<li {!! request()->is('shift') || request()->is('shift_dipinjam') ? 'class="active"' : '' !!}>
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<i class="icon-file-empty position-left"></i>@lang('trans.shift')<span class="caret"></span>
					</a>
					<ul class="dropdown-menu dropdown-menu-right">
						<li {!! request()->is('shift') ? 'class="active"' : '' !!}><a href="{{ url('shift') }}"><i class="icon-file-plus"></i>@lang('trans.shift')</a></li>
						<li {!! request()->is('shift_dipinjam') ? 'class="active"' : '' !!}><a href="{{ url('shift_dipinjam') }}"><i class="icon-file-check"></i>@lang('trans.shift_dipinjam')</a></li>
					</ul>
				</li>
				@endif

				@if (auth()->user()->role == 1)
				<li {!! request()->is('store') ? 'class="active"' : '' !!}><a href="{{ url('store') }}"><i class="icon-store position-left"></i>@lang('trans.store')</a></li>
				<li {!! request()->is('report_store') || request()->is('report_all') ? 'class="active"' : '' !!}>
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<i class="icon-book3 position-left"></i>@lang('trans.report')<span class="caret"></span>
					</a>
					<ul class="dropdown-menu dropdown-menu-right">
						<li {!! request()->is('report_store') ? 'class="active"' : '' !!}><a href="{{ url('report_store') }}"><i class="icon-store"></i>@lang('trans.per_store')</a></li>
						<li {!! request()->is('report_all') ? 'class="active"' : '' !!}><a href="{{ url('report_all') }}"><i class="icon-stack-empty"></i>@lang('trans.all')</a></li>
					</ul>
				</li>
				@endif

				
			</ul>

			<ul class="nav navbar-nav navbar-right">
				
				@php
					$notifications = App\Shift::select('shifts.*', 'from_store.name as from_store', 'to_store.name AS to_store', 'stock_masters.brand', 'stock_masters.type', 'stock_masters.size')
						                        ->join('stores AS from_store', 'from_store.code', '=', 'shifts.from_store')
						                        ->join('stores AS to_store', 'to_store.code', '=', 'shifts.to_store')
						                        ->join('stock_masters', 'stock_masters.jan_code', '=', 'shifts.jan_code')
						                        ->where('shifts.to_store', auth()->user()->store_code)
						                        ->where('status', 'acc')
						                        ->get();
				@endphp 

				@if (auth()->user()->role == 2)
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-bubbles4"></i>
						<span class="visible-xs-inline-block position-right">Notifications</span>
						@if ($notifications->count() != 0) <span class="badge bg-warning-400">{{ $notifications->count() }}</span> @endif
					</a>
					<div class="dropdown-menu dropdown-content width-350">
						<div class="dropdown-content-heading">
							Notifications
						</div>
						<ul class="media-list dropdown-content-body">
							@foreach ($notifications as $notification)
							<li class="media">
								<div class="media-body">
									<span class="media-heading text-primary">
										<a href="{{ url('shift_dipinjam') }}"><i class="icon-arrow-right7 mr-10 ml-10 position-left"></i><span class="text-semibold">{{ $notification->from_store }}</span> </a>
										<span class="media-annotation pull-right">{{ date('Y年m月d日', strtotime($notification->created_at)) }}</span>
									</span>
									<span class="text-muted">
										{{ $notification->brand }} {{ $notification->size }} ({{ $notification->amount }})
									</span>
								</div>
							</li>
							@endforeach
						</ul>
					</div>
				</li>
				@endif
				@if (auth()->user()->role == 1)
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-cog3"></i>
						<span class="visible-xs-inline-block position-right">Share</span>
						<span class="caret"></span>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a href="{{ url('translate') }}"><i class="icon-sphere"></i> @lang('trans.language')</a></li>
					</ul>
				</li>
				@endif
			</ul>
		</div>
	</div>
	<!-- /second navbar -->

	@section('header')
	<!-- Page header -->
	<div class="page-header">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">@yield('header-title')</span></h4>
			</div>
		</div>
	</div>
	<!-- /page header -->
	@show

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				@yield('content')
			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->
	</div>
	<!-- /page container -->


	<!-- Footer -->
	<div class="footer text-muted">
		&copy; 2018 <a href="#">アキヤマグループ倉庫管理</a> by <a href="http://sumroch.com" target="_blank">Sumroch</a>
	</div>
	<!-- /footer -->
	@stack('vue')
</body>
</html>
