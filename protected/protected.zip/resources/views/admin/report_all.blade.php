@extends('layouts.admin')

@push('css')
@endpush
{{-- ================================================================================================================================= --}}
@push('sec-js')
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/selects/select2.min.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@push('js')
<script type="text/javascript" src="{{ asset('js/mixin.'.auth()->user()->language.'.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@section('header')
	@parent
	@section('header-title', __('trans.report_per_store'))
@endsection
{{-- ================================================================================================================================= --}}
@section('content')
<component id="controller">
{{-- <div class="row">
	<div class="col-sm-6 col-md-3">
		<div class="panel panel-body bg-default has-bg-image p-10">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin" id="total_last_month">0</h3>
					<span class="text-uppercase text-size-mini">@lang('total_price_last_month')</span>
				</div>

				<div class="media-right media-middle">
					<i class="icon-cube3 icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>

	<div class="col-sm-6 col-md-3">
		<div class="panel panel-body bg-default has-bg-image p-10">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin" id="in_this_month">0</h3>
					<span class="text-uppercase text-size-mini">@lang('total_price_stock_in_this_month')</span>
				</div>

				<div class="media-right media-middle">
					<i class="icon-cube icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>

	<div class="col-sm-6 col-md-3">
		<div class="panel panel-body bg-default has-bg-image p-10">
			<div class="media no-margin">
				<div class="media-left media-middle">
					<i class="icon-stack3 icon-3x opacity-75"></i>
				</div>

				<div class="media-body text-right">
					<h3 class="no-margin" id="out_this_month">0</h3>
					<span class="text-uppercase text-size-mini">@lang('total_price_stock_out_this_month')</span>
				</div>
			</div>
		</div>
	</div>

	<div class="col-sm-6 col-md-3">
		<div class="panel panel-body bg-default has-bg-image p-10">
			<div class="media no-margin">
				<div class="media-left media-middle">
					<i class="icon-cube2 icon-3x opacity-75"></i>
				</div>

				<div class="media-body text-right">
					<h3 class="no-margin" id="total_this_month">0</h3>
					<span class="text-uppercase text-size-mini">@lang('total_price_this_month')</span>
				</div>
			</div>
		</div>
	</div>
</div> --}}

<div class="panel panel-default">
	<div class="panel-heading">
		<div class="row">
			<div class="col-md-3 col-sm-12">
				<h4 class="no-margin">@lang('trans.report_all')</h4>
			</div>
			<div class="col-md-9 col-sm-12 text-right form-inline">
				<a href="{{ url('excel/export_report_all') }}" class="btn btn-default"><i class="icon-file-excel"></i></a>
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-bordered table-striped table-hover table-xxs">
			<thead>
				<tr>
					<th class="text-center">@lang('trans.no')</th>
					<th class="text-center">@lang('trans.date')</th>
					<th class="text-center">@lang('trans.store_name')</th>
					<th class="text-center">@lang('trans.amount_stock_last_month')</th>
					<th class="text-center">@lang('trans.price_stock_last_month')</th>
					<th class="text-center">@lang('trans.amount_in_stock_this_month')</th>
					<th class="text-center">@lang('trans.price_stock_in_this_month')</th>
					<th class="text-center">@lang('trans.sell_amount')</th>
					<th class="text-center">@lang('trans.price_stock_out_this_month')</th>
					<th nowrap class="text-center">@lang('trans.barang_titip')</th>
					<th class="text-center">@lang('trans.price_barang_titip')</th>
					<th class="text-center">@lang('trans.amount_stock_this_month')</th>
					<th class="text-center">@lang('trans.price_stock_this_month')</th>
				</tr>
			</thead>

			<tbody>
				@foreach ($stores as $store)
				<tr>
					<td class="text-center">{{ $loop->index+1 }}</td>
					<td nowrap>{{ date('Y年m月d日', strtotime($store->date)) }}</td>
					<td nowrap>{{ $store->name }}</td>
					<td class="text-center">{{ $store->stock_in_last_month-$store->stock_out_last_month }}</td>
					<td class="text-right">¥{{ number_format($store->price_last_month) }}</td>
					<td class="text-center">{{ $store->stock_in_this_month }}</td>
					<td class="text-right">¥{{ number_format($store->price_stock_in_this_month) }}</td>
					<td class="text-center">{{ $store->sell_amount }}</td>
					<td class="text-right">¥{{ number_format($store->price_stock_out_this_month) }}</td>
					<td class="text-center">{{ $store->barang_titip }}</td>
					<td class="text-right">¥{{ number_format($store->price_barang_titip) }}</td>
					<td class="text-center">{{ $store->total_stock }}</td>
					<td class="text-right">¥{{ number_format($store->total_price_this_month) }}</td>
				</tr>
				@endforeach
			</tbody>	
		</table>
	</div>
</div>
<div class="pull-right"> {!! $stores->render() !!} </div>
</component>
@endsection
{{-- ================================================================================================================================= --}}
@push('vue')
@endpush