@extends('layouts.admin')

@push('css')
@endpush
{{-- ================================================================================================================================= --}}
@push('sec-js')
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/extensions/fixed_columns.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/selects/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/styling/uniform.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/moment/moment.min.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@push('js')
<script type="text/javascript" src="{{ asset('js/mixin.'.auth()->user()->language.'.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@section('header')
	@parent
	@section('header-title', __('trans.stock'))
@endsection
{{-- ================================================================================================================================= --}}
@section('content')
<component id="controller" v-cloak>
	<div id="modal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-slate-800">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="modal-title">@lang('trans.detail_stock') @{{ data.store_name }}</h5>
				</div>

				<div class="modal-body">
					<div class="row">
						<div class="col-md-3">
							<span class="text-muted">@lang('trans.stock_datetime')</span>
							<hr class="mt-10 mb-10"> 
							@{{ data.stock_datetime }}
						</div>
						<div class="col-md-3">
							<span class="text-muted">@lang('trans.jan_code')</span>
							<hr class="mt-10 mb-10">
						@{{ data.jan_code }}</span>
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.type')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.type }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.amount')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.amount }}
					</div>
				</div>
				<div class="row" style="margin-top:50px;">
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.brand')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.brand }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.size')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.size }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.price')</span>
						<hr class="mt-10 mb-10"> 
						¥@{{ data.price }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.receipts')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.receipt_number }}
					</div>
				</div>
			</div>

			<div class="modal-footer">
				<button type="button" class="btn bg-slate-800" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div id="modal-form" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" :action="actionUrl" method="post" @submit.prevent="submitForm($event)">
				{{csrf_field()}}
				<input type="hidden" name="_method" value="PUT" v-if="editStatus">

				<div class="modal-header bg-slate-800">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="modal-title" v-if="!editStatus">@lang('trans.add_stock')</h5>
					<h5 class="modal-title" v-if="editStatus">@lang('trans.edit_stock')</h5>
				</div>

				<div class="modal-body">
					<div class="form-group">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.stock_datetime')</label>
									<input type="text" class="form-control" name="stock_datetime" :value="data.stock_datetime">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.jan_code')</label>
									<input type="text" class="form-control" name="jan_code" :value="data.jan_code">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.type')</label>
									<input type="text" class="form-control" name="type" :value="data.type">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.amount')</label>
									<input type="text" class="form-control" name="amount" :value="data.amount">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.price')</label>
									<input type="text" class="form-control" name="price" :value="data.price">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.receipts')</label>
									<input type="text" class="form-control" name="receipts" :value="data.receipt_number">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.store_code')</label>
									<input type="text" class="form-control" name="store_code" :value="data.store_code">
								</div>
								<div class="col-xs-6 mb-15">
									<label class="control-label">@lang('trans.arrow')</label>
									<input type="text" class="form-control" name="arrow" :value="data.arrow">
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="modal-footer">
					<button type="submit" class="btn bg-primary">@lang('trans.save')</button>
				</div>

			</form>
		</div>
	</div>
</div>

<div id="modal-upload" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-slate-800">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h5 class="modal-title">@lang('trans.upload_stock')</h5>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<div class="col-lg-12">
						<div class="row">
							<form class="col-md-8 col-sm-12 text-left" method="post" action="{{ url('excel/upload_stock') }}" enctype="multipart/form-data">
								<div class="col-xs-6 mb-15">
									<select class="form-control select2" name="arrow">
										<option value="in" data-icon="arrow-left8" selected="selected">@lang('trans.filter_stock_in')</option>
										<option value="out" data-icon="arrow-right8">@lang('trans.filter_stock_out')</option>
									</select>


								</div>
								<div class="col-xs-6 mb-15">
									{{ csrf_field() }}
									<input type="file" class="file-styled-primary form-control" name="csv">
									<div class="input-group-btn">
										<button type="submit" class="btn btn-success btn-block btn-ladda btn-ladda-spinner" data-spinner-color="#fff" data-style="zoom-in"><i class="icon-upload position-left"></i>@lang('trans.upload')</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn bg-primary">@lang('trans.save')</button>
			</div>
		</div>
	</div>
</div>

<div class="row" style="margin-top: -80px;">
	<div class="col-sm-12 col-md-3 pull-right">
		<div class="panel panel-body bg-default has-bg-image p-10">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin" id="total_amount">0</h3>
					<span class="text-uppercase text-size-mini">@lang('total_amount')</span>
				</div>
				<div class="media-right media-middle">
					<i class="icon-cube3 icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-12"> 

		@if (session()->has('message'))
		<div class="alert alert-success">
			@lang('trans.upload_success')
		</div>
		@elseif (session()->has('message_error') || $errors->count())
		<div class="alert alert-danger">
			@lang('trans.file_not_valid')
		</div>
		@endif
		<div class="panel panel-default" style="margin-top: -8px;">
			<div class="panel-body">
				<div class="row">
					@if (auth()->user()->role === 1)
					<div class="col-md-6 form-inline">
						<select class="form-control select-store" name="store">
							@foreach (App\Store::all() as $store)
							<option value="{{ $store->code }}">{{ $store->code }} {{ $store->name }}</option>
							@endforeach
						</select>

						<div class="btn-group">
							<button type="button" class="btn bg-slate-800 btn-arrow btn-xs" arrow="in"><i class="icon-arrow-left8 position-left"></i>@lang('trans.filter_stock_in')</button>
							<button type="button" class="btn btn-default btn-arrow btn-xs" arrow="out"><i class="icon-arrow-right8 position-left"></i>@lang('trans.filter_stock_out')</button>
						</div>
					</div>
					@endif

					@if (auth()->user()->role === 2)
					<form class="col-md-6 col-sm-12 text-left form-inline" method="post" action="{{ url('data/stock') }}" enctype="multipart/form-data">
						<input type="hidden" name="store" value="{{ auth()->user()->store_code }}">
						<div class="btn-group">
							<button type="button" class="btn bg-slate-800 btn-arrow btn-xs" arrow="in"><i class="icon-arrow-left8 position-left"></i>@lang('trans.filter_stock_in')</button>
							<button type="button" class="btn btn-default btn-arrow btn-xs" arrow="out"><i class="icon-arrow-right8 position-left"></i>@lang('trans.filter_stock_out')</button>
						</div>
					</form>
					@endif


					<div class="col-md-6">
						<div class="{!! auth()->user()->role === 1 ? 'text-right' : 'text-right' !!}">
						<a href="{{ url('excel/export_stock') }}" class="btn btn-default"><i class="icon-file-excel"></i></a>

							<select class="form-control select2" name="filter">
								<option value="per_year" data-icon="calendar3">@lang('trans.per_year')</option>
								<option value="per_month" selected="selected" data-icon="calendar2">@lang('trans.per_month')</option>
								<option value="per_day" data-icon="calendar52">@lang('trans.per_day')</option>
							</select>

							<select class="select-nosearch" name="year">
								@foreach (range(2016, date('Y')+1) as $year)
								<option {!! $year == date('Y') ? 'selected' : '' !!} value="{{ $year }}">{{ date_format2($year, 'Y', 'jp') }}</option>
								@endforeach
							</select>

							<select class="select-nosearch" name="month">
								@foreach (range(1, 12) as $month)
								<option {!! $month == date('m') ? 'selected' : '' !!} value="{{ $month }}">{{ date_format2($month, 'm', 'jp') }}</option>
								@endforeach
							</select>

							<select class="select-nosearch" name="day">
								@foreach (range(1, 31) as $day)
								<option {!! $day == date('d') ? 'selected' : '' !!} value="{{ $day }}">{{ date_format2($day, 'd', 'jp') }}</option>
								@endforeach
							</select>
						</div>
					</div>
				</div>
			</div>

			<table class="table table-bordered table-striped table-hover table-xxs datatables">
				<thead>
					<tr>
						@if (auth()->user()->role === 1)
						@endif
						<th class="text-center" width="20px"><i class="icon-check"></i></th>
						<th class="text-center">@lang('trans.no')</th>
						<th class="text-center">@lang('trans.date')</th>
						<th class="text-center">@lang('trans.receipt_number')</th>
						<th class="text-center">@lang('trans.brand')</th>
						<th class="text-center">@lang('trans.version')</th>
						<th class="text-center">@lang('trans.stock_name')</th>
						<th class="text-center">@lang('trans.type')</th>
						<th class="text-center">@lang('trans.amount')</th>
						<th class="text-center">@lang('trans.basic_price')</th>
						<th class="text-center">@lang('trans.total_sales')</th>
						<th class="text-center">@lang('trans.option')</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
	{{-- <div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-body p-10">
				<h6 style="margin-left: 10px;">@lang('trans.log')</h6>
			</div>
			<table class="table">
				@foreach (range(1, 12) as $month)
				<tr>
					<td class="text-center"> {{ date_format2($month, 'm', 'jp') }} </td>
					<td class="text-center"><a href="" data-target="#modal-upload" data-toggle="modal"><i class="icon-checkmark4 text-default"></i></a></td>
				</tr>
				@endforeach
			</table>
		</div>
	</div> --}}
</div>
</component>
@endsection
{{-- ================================================================================================================================= --}}
@push('vue')
<script type="text/javascript">
	var arrow = $('.btn-arrow.bg-slate-800').attr('arrow');
	var filter = $('select[name=filter]').val();
	var date = $('select[name=year]').val()+'-'+$('select[name=month]').val()+'-'+$('select[name=day]').val();
	var store = $('select[name=store]').val();
	
	var actionUrl = URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date;
	var importUrl = URL+'excel/stock';
	var actionBtn = ! isCentral();

	if (isStore())
		var btns = [
			`<a href="`+importUrl+`" class="btn btn-default mr-5"><i class="icon-upload"></i></a>`
		];

	var columns = [
		{render: function (index, row, data) {
			return '<input type="checkbox" value="'+data.id+'" class="checkRow" onclick="controller.checkRow(event)">'
		}, orderable: false, width: '20px', class: 'text-center'},
		{data: 'DT_Row_Index', orderable: false, searchable: false, width: '20px', class: 'text-center'},
		{data: 'stock_datetime', orderable: false, searchable: false, class: 'text-center'},
		{data: 'receipt_number', class: 'text-center', orderable: false},
		{data: 'brand', class: 'text-center', orderable: false},
		{data: 'version', class: 'text-center', orderable: false},
		{data: 'stock_name', orderable: false},
		{data: 'type', class: 'text-center', orderable: false},
		{data: 'amount', class: 'text-center'},
		{data: 'price', class: 'text-right'},
		{data: 'total', class: 'text-right'},
	];

	// If authentocation is central
	// if (isCentral())
		columns.push({render: function(index, row, data, meta) {
			return `<a href="#" onclick="controller.editData(event, `+meta.row+`)">
						<i class="icon-pencil mr-10"></i>
					</a>
					<a href="#" onclick="controller.deleteData(event, `+data.id+`)">
						<i class="icon-trash text-danger"></i>
					</a>`;
		}, class: 'text-center', orderable: false, width: '85px'});
</script>
<script type="text/javascript" src="{{ asset('js/data.js') }}"></script>
<script type="text/javascript">
	$(function () {
		function iconFormat(icon) {
			var originalOption = icon.element;
			if (!icon.id) { return icon.text; }
			var $icon = "<i class='icon-" + $(icon.element).data('icon') + "'></i>" + icon.text;

			return $icon;
		}

		$('.select2').select2({
			width: 'auto',
			templateResult: iconFormat,
			minimumResultsForSearch: Infinity,
			templateSelection: iconFormat,
			escapeMarkup: function(m) { return m; }
		});

		$('.select-nosearch').select2({
			width: 'auto',
			minimumResultsForSearch: Infinity
		});

		$('.select-store').select2({
			width: '300px'
		});

		$('select[name=day]').next('.select2-container').hide();

		$('select[name=store]').on('change', function () {
			store = $(this).val();
			controller.table.ajax.url(URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date).load();
		});

		$('select[name=arrow]').on('change', function () {
			arrow = $(this).val();
			controller.table.ajax.url(URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date).load();
		});

		$('.btn-arrow').on('click', function () {
			arrow = $(this).attr('arrow');
			$('.btn-arrow.bg-slate-800').removeClass('bg-slate-800').addClass('btn-default').removeAttr('disabled');
			$(this).removeClass('btn-default').addClass('bg-slate-800').attr('disabled', 'disabled');
			controller.table.ajax.url(URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date).load();

		});

		$('select[name=filter]').on('change', function () {
			filter = $(this).val();
			controller.table.ajax.url(URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date).load();

			switch (filter) {
				case 'per_day':
					$('select[name=month]').next('.select2-container').show();
					$('select[name=day]').next('.select2-container').show();
					break;
				case 'per_month':
					$('select[name=month]').next('.select2-container').show();
					$('select[name=day]').next('.select2-container').hide();
					break;
				case 'per_year':
					$('select[name=month]').next('.select2-container').hide();
					$('select[name=day]').next('.select2-container').hide();
					break;
			}
		});

		$('.select-nosearch').on('change', function() {
			date = $('select[name=year]').val()+'-'+$('select[name=month]').val()+'-'+$('select[name=day]').val();
			controller.table.ajax.url(URL+'data/stock?store='+store+'&arrow='+arrow+'&filter='+filter+'&date='+date).load();
		});

		controller.table.on('xhr', function (response) {
			$('#total_amount').html(controller.table.ajax.json().totalAmount);
		})
	});
</script>
@endpush