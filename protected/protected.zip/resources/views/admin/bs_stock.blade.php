@extends('layouts.admin')

@push('css')
@endpush
{{-- ================================================================================================================================= --}}
@push('sec-js')
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/selects/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/styling/uniform.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/daterangepicker.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/anytime.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.date.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.time.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/legacy.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@push('js')
<script type="text/javascript" src="{{ asset('js/mixin.'.auth()->user()->language.'.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@section('header')
	@parent
	@section('header-title', __('trans.bs_stock'))
@endsection
{{-- ================================================================================================================================= --}}
@section('content')
<component id="controller">
<div id="modal-detail" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-slate-800">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h5 class="modal-title">@lang('trans.detail_bs_stock') : @{{ data.receipt_number }}</h5>
			</div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.receipt_date')</span>
						<hr class="mt-10 mb-10">
						@{{ moment(data.receipt_date).format('YYYY年MM月DD日') }}</span>
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.version')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.version }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.stock_code')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.stock_code }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.jan_code')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.jan_code }}
					</div>
				</div>
				<div class="row" style="margin-top:50px;">
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.stock_name')</span>
						<hr class="mt-10 mb-10">
						@{{ data.stock_name }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.amount')</span>
						<hr class="mt-10 mb-10"> 
						@{{ data.amount }}
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.sell_price')</span>
						<hr class="mt-10 mb-10"> 
						<p class="text-right no-margin">¥@{{ data.sell_price }}</p>
					</div>
					<div class="col-md-3">
						<span class="text-muted">@lang('trans.basic_price')</span>
						<hr class="mt-10 mb-10"> 
						<p class="text-right no-margin">¥@{{ data.basic_price }}</p>
					</div>
				</div> 
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn bg-slate-800" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>
<div id="modal-form" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" :action="actionUrl" method="post" @submit="submitForm($event)">
			{{csrf_field()}}
			<input type="hidden" name="_method" value="PUT" v-if="editStatus">

			<div class="modal-header bg-slate-800">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h5 class="modal-title" v-if="!editStatus">@lang('trans.add_bs_stock')</h5>
				<h5 class="modal-title" v-if="editStatus">@lang('trans.edit_bs_stock')</h5>
			</div>

			<div class="modal-body">
				<div class="form-group">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.company')</label>
								<input type="text" class="form-control" name="company_code" :value="data.company_code">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.receipt_date')</label>
								<input type="text" class="form-control pickadate-accessibility" name="receipt_date" style="background-color: #fff;" required="required" :value="data.receipt_date">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.receipt_number')</label>
								<input type="text" class="form-control" name="receipt_number" :value="data.receipt_number">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.stock_code')</label>
								<input type="text" class="form-control" name="stock_code" :value="data.stock_code">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.jan_code')</label>
								<input type="text" class="form-control" name="jan_code" :value="data.jan_code">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.stock_name')</label>
								<input type="text" class="form-control" name="stock_name" :value="data.stock_name">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.amount')</label>
								<input type="text" class="form-control" name="amount" :value="data.amount">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.sell_price')</label>
								<input type="text" class="form-control" name="sell_price" :value="data.sell_price">
							</div>
							<div class="col-xs-6 mb-15">
								<label class="control-label">@lang('trans.basic_price')</label>
								<input type="text" class="form-control" name="basic_price" :value="data.basic_price">
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="modal-footer">
				<button type="submit" class="btn bg-primary">@lang('trans.save')</button>
			</div>
			
			</form>
		</div>
	</div>
</div>
<div class="panel panel-default">
	<table class="table table-bordered table-striped table-hover table-xxs datatable-responsive datatables">
		<thead>
			<tr>
				<th><i class="icon-check"></i></th>
				<th class="text-center">@lang('trans.no')</th>
				<th class="text-center">@lang('trans.receipt_date')</th>
				<th class="text-center">@lang('trans.receipt_number')</th>
				<th class="text-center">@lang('trans.stock_name')</th>
				<th class="text-center">@lang('trans.amount')</th>
				<th class="text-center">@lang('trans.total_sales')</th>
				<th class="text-center">@lang('trans.basic_price')</th>
				@if (auth()->user()->role === 1)
				<th class="text-center">@lang('trans.option')</th>
				@endif
			</tr>
		</thead>
	</table>
</div>
</component>
@endsection
{{-- ================================================================================================================================= --}}
@push('vue')
<script type="text/javascript">
	var actionUrl = URL+'data/bs_stock';
	var importUrl = URL+'excel/bs_stock';
	var actionBtn = true;
	var btns = [
		`<a href="`+importUrl+`" class="btn btn-default mr-5"><i class="icon-upload"></i></a>`
	];
	
	var columns = [
		{render: function (index, row, data) {
			return '<input type="checkbox" value="'+data.id+'" class="checkRow" onclick="controller.checkRow(event)">'
		}, orderable: false, width: '20px', class: 'text-center'},
		{data: 'DT_Row_Index', width: '20px', class:'text-center', orderable: false, searchable: false},
		{render: function (index, row, data){
			return moment(data.receipt_date).format('YYYY年MM月DD日')
		}, class: 'text-center'},
		{render: function (index, row, data, meta) {
			return `<a href="#" onclick="controller.selectData(event, `+meta.row+`)">`+data.receipt_number+`</a>`;
		}, class: 'text-center', orderable: false},
		{data: 'stock_name', class: 'text-left', orderable: false},
		{data: 'amount', class: 'text-center'},
		{render: function (index, row, data) {
			return currency(data.sell_price);
		}, class: 'text-right'},
		{render: function (index, row, data) {
			return currency(data.basic_price);
		}, class: 'text-right'},
	];

	// If authentocation is central
	if (isCentral())
		columns.push({render: function(index, row, data, meta) {
			return `<a href="#" onclick="controller.editData(event, `+meta.row+`)">
						<i class="icon-pencil mr-10"></i>
					</a>
					<a href="#" onclick="controller.deleteData(event, `+data.id+`)">
						<i class="icon-trash text-danger"></i>
					</a>`;
		}, class: 'text-center', orderable: false, width: '85px'});

</script>
<script type="text/javascript" src="{{ asset('js/data.js') }}"></script>
@endpush