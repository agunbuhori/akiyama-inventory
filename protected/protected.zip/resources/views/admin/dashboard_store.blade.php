@extends('layouts.admin')

@push('css')
@endpush
{{-- ================================================================================================================================= --}}
@push('sec-js')
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/selects/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/styling/uniform.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/daterangepicker.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/anytime.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.date.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/picker.time.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/pickers/pickadate/legacy.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/js/plugins/visualization/echarts/echarts.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@push('js')
<script type="text/javascript" src="{{ asset('js/mixin.'.auth()->user()->language.'.js') }}"></script>
<script type="text/javascript">
	var brands = {!! json_encode($brands) !!};
	var graph_bar_store = {!! json_encode($graph_bar_store) !!};
	var graph_pie_store = {!! json_encode($graph_pie_store) !!};
</script>
<script type="text/javascript" src="{{ asset('js/graph_store.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@section('header')
	@parent
	@section('header-title', __('trans.dashboard'))
@endsection
{{-- ================================================================================================================================= --}}
@section('content')
<component id="controller">
<div id="modal-form" class="modal fade">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<form class="form-horizontal" action="{{ url('data/shift') }}" method="post">
				{{csrf_field()}}
				<div class="modal-header bg-slate-800">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="modal-title">@lang('trans.add_request')</h5>
				</div>
				<input type="hidden" name="jan_code" :value="data.jan_code">
				<input type="hidden" name="to_store" :value="data.store_code">
				<div class="modal-body">
					<div class="form-group">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-md-4">
									<span class="text-muted">@lang('trans.to_store')</span>
								</div>
								<div class="col-md-8 mb-10">
									@{{ data.name }}
								</div>
								<hr width="95%"> 
								<div class="col-md-4">
									<span class="text-muted">@lang('trans.brand')</span>
								</div>
								<div class="col-md-8 mb-10">
									@{{ data.brand }}
								</div>
								<hr width="95%"> 
								<div class="col-md-4">
									<span class="text-muted">@lang('trans.type')</span>
								</div>
								<div class="col-md-8 mb-10">
									@{{ data.type }}
								</div>
								<hr width="95%"> 
								<div class="col-md-4">
									<span class="text-muted">@lang('trans.size')</span>
								</div>
								<div class="col-md-8 mb-10">
									@{{ data.size }}
								</div>
								<hr width="95%">
							</div>
							<div class="row">
								<div class="col-xs-12 mb-15">
									<label class="control-label">@lang('trans.amount')</label>
									<input type="number" class="form-control" name="amount">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn bg-primary">@lang('trans.save')</button>
				</div>
			</form>
		</div>
	</div>
</div>

<ul class="nav nav-tabs nav-tabs-bottom">
	<li class="active"><a href="#bottom-tab1" data-toggle="tab">@lang('trans.graph')</a></li>
	<li><a href="#bottom-tab2" data-toggle="tab">@lang('trans.transfer_request')</a></li>
</ul>

<div class="tab-content">
	<div class="tab-pane active" id="bottom-tab1">
		<div class="row">
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h5 class="panel-title">@lang('trans.graph_bar')</h5>
					</div>

					<div class="panel-body">
						<div class="chart-container">
							<div class="chart has-fixed-height" id="basic_bars" style="height: 250px;"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">@lang('trans.graph_pie')</h5>
						</div>
						<div class="panel-body">
							<div class="chart-container">
								<div class="chart has-fixed-height" id="basic_pie" style="height: 250px;"></div>
							</div>
						</div>
					</div>		
				</div>
			</div>
		</div>
	</div>

	<div class="tab-pane" id="bottom-tab2">
		<div class="panel panel-flat">
			<div class="panel-heading">
				<h5 class="panel-title">@lang('trans.search_stock')<a class="heading-elements-toggle"><i class="icon-more"></i></a></h5>
			</div>
			<div class="panel-body">
				<form action="{{ url('dashboard') }}" method="get">
					<div class="input-group content-group">
						<div class="has-feedback has-feedback-left">
							<input type="text" name="search" class="form-control input-xlg" placeholder="キーワードを入力" value="{{ request()->search }}">
							<div class="form-control-feedback">
								<i class="icon-search4 text-muted text-size-base"></i>
							</div>
						</div>
						<div class="input-group-btn">
							<button type="submit" class="btn btn-primary btn-xlg">@lang('trans.search')</button>
						</div>
					</div>
				</form>
			</div>
		</div>

		@if (request()->has('search') && request()->search != '')
		<div class="panel panel-default">
			<table class="table table-bordered table-striped table-hover table-xxs">
				<thead>
					<tr>
						<th class="text-center" width="40px">@lang('trans.no')</th>
						<th class="text-center">@lang('trans.store')</th>
						<th class="text-center">@lang('trans.brand')</th>
						<th class="text-center">@lang('trans.type')</th>
						<th class="text-center">@lang('trans.size')</th>
						<th class="text-center">@lang('trans.version')</th>
						<th class="text-center">@lang('trans.amount')</th>
						<th class="text-center">@lang('trans.option')</th>
					</tr>
				</thead>
				<tbody>
					@foreach ($stocks as $index => $data)
					<tr>
						<td class="text-center">{{ $index+1 }}</td>
						<td>{{ $data->name }}</td>
						<td>{{ $data->brand }}</td>
						<td class="text-center">{{ $data->type }}</td>
						<td>{{ $data->size }}</td>
						<td>{{ $data->version }}</td>
						<td class="text-center">{{ $data->amount }}</td>
						<td class="text-center"><a href="" @click="addData(event, {{ $data }} )" data-target="#modal-form" data-toggle="modal">@lang('trans.request')</a></td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<div class="pull-right"> {!! $stocks->render() !!} </div>
		@endif
	</div>
</div>



</component>
@endsection
{{-- ================================================================================================================================= --}}
@push('vue')
<script type="text/javascript">
	var controller = new Vue({
		el : '#controller',
		data : {
			data : {},
		},
		mounted: function() {

		},
		methods: {
			addData(event, data) {
				this.data = data;
			}
		}
	})
</script>
<script type="text/javascript" src="{{ asset('js/datatable.select2.js') }}"></script>
@endpush