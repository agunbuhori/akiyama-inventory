@extends('layouts.admin')

@push('css')
@endpush
{{-- ================================================================================================================================= --}}
@push('sec-js')
<script type="text/javascript" src="{{ asset('assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/selects/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/forms/styling/uniform.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/ui/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/plugins/visualization/echarts/echarts.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@push('js')
<script type="text/javascript" src="{{ asset('js/datatable.jp.js') }}"></script>
<script type="text/javascript">
	var stores = {!! json_encode($stores) !!};
	var brands = {!! json_encode($brands) !!};
    var graph_bar = {!! json_encode($graph_bar) !!};
    var graph_line = {!! json_encode($graph_line) !!};
    var graph_column = {!! json_encode($graph_column) !!};
    var graph_pie = {!! json_encode($graph_pie) !!};
</script>
<script type="text/javascript" src="{{ asset('js/graph.js') }}"></script>
@endpush
{{-- ================================================================================================================================= --}}
@section('header')
	@parent
	@section('header-title', __('trans.dashboard'))
@endsection

@section('content')
<component id="dashboard">

	<ul class="nav nav-tabs nav-tabs-bottom">
		<li class="active"><a href="#bottom-tab1" data-toggle="tab">@lang('trans.graph_bar')</a></li>
		<li><a href="#bottom-tab2" data-toggle="tab">@lang('trans.graph_pie')</a></li>
		<li><a href="#bottom-tab3" data-toggle="tab">@lang('trans.graph_column')</a></li>
		<li><a href="#bottom-tab4" data-toggle="tab">@lang('trans.graph_line')</a></li>
	</ul>

	<div class="tab-content">
		<div class="tab-pane active" id="bottom-tab1">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">@lang('trans.graph_bar')</h5>
						</div>
						<div class="panel-body">
							<div class="chart-container"> 
								<center>
									<div class="chart has-fixed-height" id="stacked_bars" style="height: 450px; width: 1200px;"></div>
								</center>
							</div>
						</div>
					</div>			
				</div>
				
			</div>
		</div>

		<div class="tab-pane" id="bottom-tab2">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">@lang('trans.graph_pie')</h5>
						</div>
						<div class="panel-body">
							<div class="chart-container">
								<center>
									<div class="chart has-fixed-height" id="basic_pie" style="height: 400px; width: 1200px;"></div>
								</center>
							</div>
						</div>
					</div>		
				</div>
			</div>
		</div>

		<div class="tab-pane" id="bottom-tab3">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">@lang('trans.graph_column')</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li> @lang('trans.satuan_per_10000') </li>
			                	</ul>
		                	</div>
						</div>

						<div class="panel-body">
							<div class="chart-container">
								<center>
									<div class="chart has-fixed-height" id="stacked_columns" style="height: 400px; width: 1200px;"></div>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="tab-pane" id="bottom-tab4">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">@lang('trans.graph_line')</h5>

						</div>

						<div class="panel-body">
							<div class="chart-container">
								<center>
									<div class="chart has-fixed-height" id="stacked_lines" style="height: 400px; width: 1200px;"></div>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


</component>
@endsection
{{-- ================================================================================================================================= --}}
@push('vue')
<script type="text/javascript" src="{{ asset('js/datatable.select2.js') }}"></script>
@endpush