<?php

namespace App\Http\Controllers;

use App\BsStock;
use Illuminate\Http\Request;

class BsStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function show(BsStock $bsStock)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function edit(BsStock $bsStock)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BsStock $bsStock)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function destroy(BsStock $bsStock)
    {
        //
    }
}
