<?php

namespace App\Http\Controllers;

use DB;
use Excel;
use App\Store;
use App\Shift;
use App\Stock;
use App\BsStock;
use App\StockMaster;
use Illuminate\Http\Request;

class ExcelController extends Controller
{
	public function importStockMasterForm()
	{
		return view('admin.import_stock_master');
	}

    public function importStockMaster(Request $request)
    {
    	$this->validate($request, [
    	    'csv' => 'required|mimes:csv,xls,xlsx,txt'
    	]);

    	$stockMasters = Excel::load($request->csv, function($reader) { $reader->noHeading = true; }, 'UTF-8')->toArray();
    	$userId = auth()->user()->id;

        if (count($stockMasters[0]) < 16 || count($stockMasters[0]) > 17)
            abort(422, "file not valid");

        unset($stockMasters[0]);


    	$data = [];

    	foreach ($stockMasters as $stockMaster) {
    	    $data[] = [
    	        'season' => $stockMaster[1],
    	        'code' => $stockMaster[2],
    	        'brand' => $stockMaster[3],
    	        'version' => $stockMaster[4],
    	        'size' => $stockMaster[5],
    	        'section' => $stockMaster[6],
    	        'series' => $stockMaster[7],
    	        'rim' => $stockMaster[8],
    	        'jan_code' => $stockMaster[9],
    	        'type' => $stockMaster[12],
    	        'user_id' => $userId
    	    ];
    	}

    	StockMaster::insert($data);

    	return count($stockMasters);
    }

    public function importBsStockForm()
    {
        return view('admin.import_bs_stock');
    }

    public function importBsStock(Request $request)
    {
        // $this->validate($request, [
        //     'csv' => 'required|mimes:csv,xls,xlsx,txt'
        // ]);

        $bsStocks = Excel::load($request->csv, function($reader) { $reader->noHeading = true; }, 'UTF-8')->toArray();
        $userId = auth()->user()->id;

        if ($bsStocks)
            $bsStocks = array_slice($bsStocks[0], 1);
        $data = [];

        foreach ($bsStocks as $bsStock) {
            if (! $bsStock[8])
                continue;
            
            $jan_code = DB::table('stock_masters')->select('jan_code')->where('id', rand(1, 3708))->first();
            $jan_code = $jan_code ? $jan_code->jan_code : $bsStock[8];

            $row = [
                'company_code' => $bsStock[0],
                'company_name' => $bsStock[1],
                'receipt_date' => $bsStock[3],
                'receipt_number' => $bsStock[4],
                'article' => $bsStock[5],
                'group' => $bsStock[6],
                'stock_code' => $bsStock[7],
                'jan_code' => $jan_code,
                'stock_name' => $bsStock[9],
                'barang_titip' => $bsStock[10],
                'amount' => $bsStock[11],
                'sell_price' => $bsStock[12],
                'basic_price' => $bsStock[13],
                'memo' => $bsStock[14],
                'user_id' => $userId
            ];

            // if (preg_match('/^[0-9]{3}+[A-Z]{1}+\ [0-9]+\/[0-9]+\ [A-Z]+[0-9]+/', $bsStock[9])) {
            //     $explode = explode(' ', $bsStock[9]);
            //     $row['size'] = $explode[0].' '.$explode[1].' '.$explode[2];
            //     $row['section'] = substr($explode[1], 0, 3);
            //     $row['series'] = substr($explode[1], 4, 6);
            //     $row['rim'] = substr($explode[2], 1, 2);
            //     $row['type'] = 'ban';
            // } else {
            //     $row['size'] = null;
            //     $row['section'] = null;
            //     $row['series'] = null;
            //     $row['rim'] = null;
            //     $row['type'] = 'baterai';
            // }

            $data[] = $row;
        }

        BsStock::insert($data);

        return count($bsStocks);
    }

    public function importStockForm()
    {
        return view('admin.import_stock');
    }

    public function importStock(Request $request)
    {
        $this->validate($request, [
            'csv' => 'required|mimes:csv,xls,xlsx,txt'
        ]);

        if ($request->csv)
            $rows = Excel::load($request->csv, function($reader) { $reader->noHeading = true; }, 'Shift-JIS')->toArray();


        if (count($rows) === 0 || count($rows[0]) === 0 || count($rows[0]) > 10 || count($rows[0]) < 9)
            return back()->with(['message_error' => 'Invalid format'], 422);

        if (preg_match('/[a-zA-Z]+/', $rows[0][0]))
            unset($rows[0]);

        $data = [];
        $arrow = $request->has('arrow') ? $request->arrow : 'in';
        $fileName = date('YmdHis_').$arrow.'.csv';

        foreach ($rows as $row)
            $data[] = [
                'stock_datetime' => convert_date($row[0], $row[1], $row[2]),
                'jan_code' => $row[6], 
                'type' => $row[5], 
                'amount' => $row[7], 
                'price' => $row[8],
                'store_code' => auth()->user()->store_code,
                'arrow' => $arrow,
                'created_at' => now()
            ];

        Stock::insert(array_values($data));
    }

    public function exportShift() {

        $title = array(
            array(' 日付', '転出店舗', '転受店舗', '商品', 'パタン', 'サイズ', '  数量')
        );

        $shifts = Shift::select('shifts.*', 'from_store.name as from_store', 'to_store.name AS to_store', 'stock_masters.brand', 'stock_masters.type', 'stock_masters.size')
                        ->join('stores AS from_store', 'from_store.code', '=', 'shifts.from_store')
                        ->join('stores AS to_store', 'to_store.code', '=', 'shifts.to_store')
                        ->join('stock_masters', 'stock_masters.jan_code', '=', 'shifts.jan_code')
                        // ->where('shifts.status', 'done')
                        ->get();
        $data = [];

        // return $shifts;

        foreach ($shifts as $key => $shift) {
            $data[$key][] = date('Y年m月d日', strtotime($shift->created_at));
            $data[$key][] = $shift->from_store;
            $data[$key][] = $shift->to_store;
            $data[$key][] = $shift->type;
            $data[$key][] = $shift->brand;
            $data[$key][] = $shift->size;
            $data[$key][] = $shift->amount;
        }

        Excel::create('転送', function($excel) use($title, $data) {

            $excel->sheet('Sheetname', function($sheet) use($title, $data) {
                
                $sheet->fromArray($title)->fromArray($data);

                $sheet->mergeCells('A1:G1');
                $sheet->mergeCells('A2:A3');
                $sheet->mergeCells('B2:B3');
                $sheet->mergeCells('C2:C3');
                $sheet->mergeCells('D2:D3');
                $sheet->mergeCells('E2:E3');
                $sheet->mergeCells('F2:F3');
                $sheet->mergeCells('G2:G3');

                $sheet->cells('A2:G3', function($cells) {
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                    $cells->setFontWeight('bold');
                });

                $sheet->cell('A1', function($cell) {
                    $cell->setValue("転送");
                    $cell->setFontSize(14);
                    $cell->setValignment('center');
                    $cell->setAlignment('center');
                    $cell->setFontWeight('bold');
                });

                $sheet->setBorder('A1:G2', 'thin');

                $sheet->cells('A4:A54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('B4:B54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('C4:C54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('D4:D54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('E4:E54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('F4:F54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('G4:G54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('G4:G54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('D4:D54', function($cells) {
                    $cells->setAlignment('center');
                }); 


                $sheet->setHeight(array(
                    1   => 40
                ));

                $sheet->setWidth(array(
                    'A'    => 20,
                    'B'    => 20,
                    'C'    => 20,
                    'D'    => 20,
                    'E'    => 25,
                    'F'    => 25,
                    'G'    => 15
                ));

                $sheet->row(1, function($row) {
                    $row->setBackground('#BDD7EE');
                });

                $sheet->row(2, function($row) {
                    $row->setBackground('#EEEEEE');
                });

                for ($a=4;$a<=54;$a++){
                     if ($a % 2 == 1) {
                         $sheet->cells('A'.$a.':G'.$a, function($cells) {
                             $cells->setBackground('#EEEEEE');
                         });
                     }
                }

            });

        })->download('xls');
    }

    public function exportStock() {

        $title = array(
            array('日付', '伝票番号', 'パタン', 'Version', '商品名', '商品', '数量', '原価')
        );

        $stocks = Stock::select('stocks.*', 'stores.name', 'stock_masters.brand', 'stock_masters.version', 'stock_masters.type', 'bs_stocks.stock_name', 'bs_stocks.receipt_number as receipt')
                            // ->join('documents', 'documents.id', '=', 'stocks.document_id')
                            ->join('stores', 'stores.code', '=', 'stocks.store_code')
                            ->join('stock_masters', 'stock_masters.jan_code', '=', 'stocks.jan_code')
                            ->join('bs_stocks', 'bs_stocks.jan_code', '=', 'stocks.jan_code')
                            ->limit(50)
                            ->get();

        // $row = $stocks->count();
        
        $data = [];

        // return $row;

        foreach ($stocks as $key => $stock) {
            $data[$key][] = date('Y年m月d日', strtotime($stock->stock_datetime));
            $data[$key][] = $stock->receipt;
            $data[$key][] = $stock->brand;
            $data[$key][] = $stock->version;
            $data[$key][] = $stock->stock_name;
            $data[$key][] = $stock->type;
            $data[$key][] = $stock->amount;
            $data[$key][] = currency($stock->price, 'jp');
        }

        Excel::create('商品', function($excel) use($title, $data) {

            $excel->sheet('Sheetname', function($sheet) use($title, $data) {
                
                $sheet->fromArray($title)->fromArray($data);

                $sheet->mergeCells('A1:H1');
                $sheet->mergeCells('A2:A3');
                $sheet->mergeCells('B2:B3');
                $sheet->mergeCells('C2:C3');
                $sheet->mergeCells('D2:D3');
                $sheet->mergeCells('E2:E3');
                $sheet->mergeCells('F2:F3');
                $sheet->mergeCells('G2:G3');
                $sheet->mergeCells('H2:H3');

                $sheet->cells('A2:H3', function($cells) {
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                    $cells->setFontWeight('bold');
                });

                $sheet->cell('A1', function($cell) {
                    $cell->setValue("商品");
                    $cell->setFontSize(14);
                    $cell->setValignment('center');
                    $cell->setAlignment('center');
                    $cell->setFontWeight('bold');
                });

                $sheet->setWidth(array(
                    'A'    => 20,
                    'B'    => 20,
                    'C'    => 15,
                    'D'    => 30,
                    'E'    => 40,
                    'F'    => 20,
                    'G'    => 15,
                    'H'    => 15
                ));

                $sheet->setHeight(array(
                    1   => 40
                ));

                $sheet->cells('D4:E54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('A4:A54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('F4:G54', function($cells) {
                    $cells->setAlignment('center');
                });

                $sheet->cells('H4:H54', function($cells) {
                    $cells->setAlignment('right');
                });  

                $sheet->row(1, function($row) {
                    $row->setBackground('#e2efda');
                });

                $sheet->row(2, function($row) {
                    $row->setBackground('#a9d08e');
                });

                $sheet->setBorder('A1:H2', 'thin');

                $sheet->cells('A4:A54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('C4:C54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('E4:E54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('G4:G54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('H4:H54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('A54:H54', function($cells) {
                    $cells->setBorder('none', 'none', 'none', 'thin');
                });

                for ($a=4;$a<=54;$a++){
                     if ($a % 2 == 1) {
                         $sheet->cells('A'.$a.':H'.$a, function($cells) {
                             $cells->setBackground('#e2efda');
                         });
                     }
                }

            });

        })->download('xls');
    }

    public function exportReport() {
        $reports = Store::all();

        // $admin = new \App\Http\Controllers\AdminController;

        // $reports = $admin->reportApi(new Request);

        // return $reports;

        $title = array(
            array('日付', 'パタン', 'セクション', 'シリーズ', 'リム', '', '', '前月在庫本数', '入庫', '原価', '出庫', '売価', '当月在庫本数', '誤差', 'Barang Titip', 'Note')
        );

        $name = '各店舗集計 '.date('Y年m月d日');     
        $data = [];

        foreach ($reports as $key => $report) {
            $data[$key][] = $report->stock_datetime;
        }

        Excel::create($name, function($excel) use($title, $data, $name) {

            $excel->sheet('Sheetname', function($sheet) use($title, $data, $name) {

                $sheet->fromArray($title)->fromArray($data);

                $sheet->mergeCells('A1:P1');
                $sheet->mergeCells('A2:A3');
                $sheet->mergeCells('B2:B3');
                $sheet->mergeCells('C2:C3');
                $sheet->mergeCells('D2:D3');
                $sheet->mergeCells('E2:G3');
                $sheet->mergeCells('H2:H3');
                $sheet->mergeCells('I2:I3');
                $sheet->mergeCells('J2:J3');
                $sheet->mergeCells('K2:K3');
                $sheet->mergeCells('L2:L3');
                $sheet->mergeCells('M2:M3');
                $sheet->mergeCells('N2:N3');
                $sheet->mergeCells('O2:O3');
                $sheet->mergeCells('P2:P3');

                $sheet->cells('A2:P3', function($cells) {
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                    $cells->setFontWeight('bold');
                });

                $sheet->cell('A1', function($cell) {
                    $cell->setValue("各店舗集計");
                    $cell->setFontSize(14);
                    $cell->setValignment('center');
                    $cell->setAlignment('center');
                    $cell->setFontWeight('bold');
                });

                $sheet->setBorder('A1:P2', 'thin');

                $sheet->cells('A4:A54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('B4:B54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('C4:C54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('D4:D54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('E4:E54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('F4:F54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('G4:G54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('H4:H54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('I4:I54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('J4:J54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('K4:K54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('L4:L54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('M4:M54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('N4:N54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('O4:O54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('P4:P54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('E4:I54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('K4:K54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('M4:N54', function($cells) {
                    $cells->setAlignment('center');
                }); 

                $sheet->cells('J4:J54', function($cells) {
                    $cells->setAlignment('right');
                }); 

                $sheet->cells('L4:L54', function($cells) {
                    $cells->setAlignment('right');
                }); 

                $sheet->setHeight(array(
                    1   => 40
                ));

                $sheet->setWidth(array(
                    'A'    => 20,
                    'B'    => 20,
                    'C'    => 15,
                    'D'    => 30,
                    'E'    => 5,
                    'F'    => 5,
                    'G'    => 5,
                    'H'    => 20,
                    'I'    => 10,
                    'J'    => 10,
                    'K'    => 10,
                    'L'    => 10,
                    'M'    => 15,
                    'N'    => 10,
                    'O'    => 15,
                    'P'    => 10
                ));

                $sheet->row(1, function($row) {
                    $row->setBackground('#BDD7EE');
                });

                $sheet->row(2, function($row) {
                    $row->setBackground('#EEEEEE');
                });

                for ($a=4;$a<=54;$a++){
                     if ($a % 2 == 1) {
                         $sheet->cells('A'.$a.':P'.$a, function($cells) {
                             $cells->setBackground('#EEEEEE');
                         });
                     }
                }

            });

        })->export('xls');;
    }

    public function exportReportAll() {
        $title = array(
            array('Date', 'Store', 'Stock Last Month', 'Price Last Month', 'Stock In This Month', 'Price In This Month', 'Stock Out', 'Sell Price This Month', 'Stock This Month', 'Price This Month')
        );

        $reports = StockMaster::limit(5)->get();
        $data = [];

        foreach ($reports as $key => $report) {
            $data[$key][] = "";
        }

        Excel::create('全店舗集計', function($excel) use($title, $data) {

            $excel->sheet('Sheetname', function($sheet) use($title, $data) {

                $sheet->fromArray($title)->fromArray($data);

                $sheet->mergeCells('A1:J1');
                $sheet->mergeCells('A2:A3');
                $sheet->mergeCells('B2:B3');
                $sheet->mergeCells('C2:C3');
                $sheet->mergeCells('D2:D3');
                $sheet->mergeCells('E2:E3');
                $sheet->mergeCells('F2:F3');
                $sheet->mergeCells('G2:G3');
                $sheet->mergeCells('H2:H3');
                $sheet->mergeCells('I2:I3');
                $sheet->mergeCells('J2:J3');

                $sheet->cells('A2:J3', function($cells) {
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                    $cells->setFontWeight('bold');
                });

                $sheet->cell('A1', function($cell) {
                    $cell->setValue("全店舗集計");
                    $cell->setFontSize(14);
                    $cell->setValignment('center');
                    $cell->setAlignment('center');
                    $cell->setFontWeight('bold');
                });

                $sheet->setBorder('A1:J2', 'thin');

                $sheet->cells('A4:A54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('B4:B54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('C4:C54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('D4:D54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('E4:E54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('F4:F54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('G4:G54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('H4:H54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('I4:I54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });

                $sheet->cells('J4:J54', function($cells) {
                    $cells->setBorder('none', 'thin', 'thin', 'thin');
                });


                $sheet->row(1, function($row) {
                    $row->setBackground('#FFF2CC');
                });

                $sheet->row(2, function($row) {
                    $row->setBackground('#FFD996');
                });

                $sheet->setHeight(array(
                    1   => 40
                ));

                $sheet->setWidth(array(
                    'A'    => 20,
                    'B'    => 20,
                    'C'    => 15,
                    'D'    => 20,
                    'E'    => 20,
                    'F'    => 20,
                    'G'    => 15,
                    'H'    => 25,
                    'I'    => 20,
                    'J'    => 20
                ));

                for ($a=4;$a<=54;$a++){
                     if ($a % 2 == 1) {
                         $sheet->cells('A'.$a.':J'.$a, function($cells) {
                             $cells->setBackground('#FFF2CC');
                         });
                     }
                }

            });

        })->export('xls');;
    }
}
