<?php

namespace App\Http\Controllers;

use App\Translate;
use Illuminate\Http\Request;

class JavascriptController extends Controller
{
    public function phpjs()
    {
        $userLanguage = 'jp';
        $userCurrency = '¥';

        if (auth()->check())
            switch (auth()->user()->language) {
                case 'en':
                    $userLanguage = 'english';
                    $userCurrency = '$';
                    break;
                case 'jp':
                    $userLanguage = 'japanese';
                    $userCurrency = '¥';
                    break;
                case 'id':
                    $userLanguage = 'indonesia';
                    $userCurrency = 'Rp';
                    break;
            }

        $langs = Translate::pluck($userLanguage, 'key');

        echo 'var languages = '.json_encode($langs).';';
    	$scripts = "
    		function isCentral() {
    			return ".(auth()->user()->isCentral() ? "true" : "false").";
    		}
    		function isStore() {
    			return ".(auth()->user()->isStore() ? "true" : "false").";
    		}
            function translate(word) {
                return typeof languages[word] != 'undefined' ? languages[word] : word;
            }
            function currency(num) {
                return '".$userCurrency."'+num.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, `$1,`);
            }
    	";

    	return response(trim(preg_replace('/\s\s+/', ' ', $scripts)))->header('Content-Type', 'application/javascript');
    }
}
