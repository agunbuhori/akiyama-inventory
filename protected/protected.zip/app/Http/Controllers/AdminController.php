<?php

namespace App\Http\Controllers;

use DB;
use App\User;
use App\Stock;
use App\Store;
use App\StockMaster;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('central')->only(['store', 'company', 'stockMaster', 'reportStore', 'reportAll', 'bsStock']);
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function stockMaster()
    {
    	return view('admin.stock_master');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function bsStock()
    {
        return view('admin.bs_stock');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function stock()
    {
        return view('admin.stock');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $stores = Store::all();

        return view('admin.store', compact('stores'));
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function company()
    {
        return view('admin.company');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function translate()
    {
        return view('admin.translate');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function shift()
    {
        if (auth()->user()->role == 1) {
            return view('admin.shift_central');
        } else {
            return view('admin.shift_store');
        }
    }

    public function shiftDipinjam() {
        return view('admin.shift_dipinjam');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function languageJp()
    {
        \App\User::where('id', auth()->user()->id)->update(['language' => 'jp']);

        return back();
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function languageEn()
    {
        \App\User::where('id', auth()->user()->id)->update(['language' => 'en']);

        return back();
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard(Request $request)
    {
        if (auth()->user()->role == 1) {

            $stores = DB::table('stores')->pluck('name');
            $brands = StockMaster::select('stock_masters.brand as name')
                                    ->groupBy('stock_masters.brand')
                                    ->join('stocks', 'stocks.jan_code', '=', 'stock_masters.jan_code')
                                    // ->whereMonth('stocks.stock_datetime', date('m'))
                                    ->where('stock_masters.brand', '!=', null)
                                    ->get();

            $graph_bar = $this->graphBar(new Request);
            $graph_column = $this->graphColumn(new Request);
            $graph_line = $this->graphLine(new Request);
            $graph_pie = $this->graphPie(new Request);

            return view('admin.dashboard_central', compact('graph_bar', 'stores', 'graph_column', 'graph_line', 'brands', 'graph_pie'));

        } else {
            $search = $request->input('search');

            $brands = StockMaster::select('stock_masters.brand as name')
                                    ->groupBy('stock_masters.brand')
                                    ->join('stocks', 'stocks.jan_code', '=', 'stock_masters.jan_code')
                                    // ->whereMonth('stocks.stock_datetime', date('m'))
                                    ->where('stock_masters.brand', '!=', null)
                                    ->get();

            $graph_bar_store = $this->graphBarStore(new Request);
            $graph_pie_store = $this->graphPieStore(new Request);

            $stocks = Stock::select('stocks.*', 'stores.name', 'stock_masters.brand', 'stock_masters.size', 'stock_masters.version', 'stock_masters.jan_code', DB::raw("SUM(amount) AS amount"))
                                ->join('stores', 'stores.code', '=', 'stocks.store_code')
                                ->join('stock_masters', 'stock_masters.jan_code', '=', 'stocks.jan_code')
                                ->where('stocks.arrow', 'in')
                                ->where('stock_masters.size', 'like', '%'.$search.'%')
                                ->where('stocks.store_code', '!=', auth()->user()->store_code)
                                ->groupBy('stocks.jan_code')
                                ->paginate(25);

            return view('admin.dashboard_store', compact('stocks', 'graph_bar_store', 'graph_pie_store', 'brands'));
        }
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function graphBar() {

        $stores = Store::select('name', 'code')->get();

        foreach ($stores as $store) {
            $store->ban = Stock::select(DB::raw("SUM(amount) as total"))
                                ->where('arrow', 'in')
                                ->where('store_code', $store->code)
                                ->where('type', 'タイヤ')
                                ->get();
            $store->battery = Stock::select(DB::raw("SUM(amount) as total"))
                                ->where('arrow', 'in')
                                ->where('store_code', $store->code)
                                ->where('type', 'バッテリー')
                                ->get();
        }

        $graph = [];

        $graph['ban'] = [];
        $graph['battery'] = [];

        foreach ($stores as $s) {
            $graph['ban'][] = (int)$s['ban'][0]['total'];
            $graph['battery'][] = (int)$s['battery'][0]['total'];
        }

        return $graph;
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function graphColumn() {

        $stores = Store::select('name', 'code')->get();

        foreach ($stores as $store) {
            $per_month = [];

            foreach (range(1, 12) as $month) {
                $per_month[$month] = Stock::select(DB::raw("SUM(price) as total"))
                                    ->where('arrow', 'out')
                                    ->where('store_code', $store->code)
                                    ->whereMonth('stock_datetime', $month)
                                    ->where('type', 'タイヤ')
                                    ->first();

                $per_month[$month] = $per_month[$month]->total ? $per_month[$month]->total : 0;
            }
            $store->type = 'bar';
            $store->stack = 'Advertising';
            $store->data = array_values($per_month);
            $per_month = [];
        }

        return $stores;
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */

    public function graphLine() {

        $stores = Store::select('name', 'code')->get();

        foreach ($stores as $store) {
            $per_month = [];

            foreach (range(1, 12) as $month) {
                $per_month[$month] = Stock::select(DB::raw("SUM(amount) as total"))
                                    ->where('arrow', 'out')
                                    ->where('store_code', $store->code)
                                    ->whereMonth('stock_datetime', $month)
                                    ->where('type', 'タイヤ')
                                    ->first();

                $per_month[$month] = $per_month[$month]->total ? $per_month[$month]->total : 0;
            }
            $store->type = 'line';
            $store->stack = 'Total';
            $store->data = array_values($per_month);
            $per_month = [];
        }

        return $stores;
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function graphPie() {
        $brand = StockMaster::select(DB::raw("SUM(stocks.amount) as value"), 'stock_masters.brand as name')
                                ->groupBy('stock_masters.brand')
                                ->join('stocks', 'stocks.jan_code', '=', 'stock_masters.jan_code')
                                ->where('stocks.arrow', 'out')
                                // ->whereMonth('stocks.stock_datetime', date('m'))
                                ->where('stock_masters.brand', '!=', null)
                                ->get();

        return $brand;
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function reportStore()
    {
        return view('admin.report_store');
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function reportAll(Request $request)
    {
        $store_code = $request->has('store') ? $request->store : auth()->user()->store_code;
        $date = $request->has('date') ? $request->date : today();
        $this_month = date('Y-m', strtotime($date));
        $last_month = date('Y-m', strtotime($date.'-1 month'));
        $stores = Store::paginate(10);

        foreach ($stores as $store) {
            $store->stock_in_last_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('created_at', 'like', $last_month.'%')
                                                ->where('arrow', 'in')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->stock_out_last_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('created_at', 'like', $last_month.'%')
                                                ->where('arrow', 'out')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->stock_in_this_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'in')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->stock_out_this_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'out')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->price_last_month = Stock::select(DB::raw("SUM(price) AS total"))
                                                ->where('created_at', 'like', $last_month.'%')
                                                ->where('arrow', 'out')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->price_stock_in_this_month = Stock::select(DB::raw("SUM(price) AS total"))
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'in')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->barang_titip = Stock::select(DB::raw("SUM(barang_titip) AS total"))
                                                ->join('bs_stocks', 'bs_stocks.jan_code', '=', 'stocks.jan_code')
                                                ->where('store_code', $store_code)
                                                ->first()
                                                ->total;

            $store->price_stock_out_this_month = Stock::select(DB::raw("SUM(price) AS total"))
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'out')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;

            $store->sell_amount = Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'out')
                                                ->where('store_code', $store->code)
                                                ->first()
                                                ->total;
                                                
            $store->price_barang_titip = 0;

            $store->total_stock = ($store->stock_in_last_month - $store->stock_out_last_month) + ($store->stock_in_this_month - $store->stock_out_this_month) + $store->barang_titip;
            $store->total_price_this_month = $store->price_last_month + $store->price_stock_in_this_month - $store->price_stock_out_this_month + $store->price_barang_titip;

            $store->price_last_month = $store->price_last_month > 0 ? $store->price_last_month : 0;
            $store->stock_in_this_month = $store->stock_in_this_month > 0 ? $store->stock_in_this_month : 0;
            $store->price_stock_in_this_month = $store->price_stock_in_this_month > 0 ? $store->price_stock_in_this_month : 0;
            $store->sell_amount = $store->sell_amount > 0 ? $store->sell_amount : 0;
            $store->price_stock_out_this_month = $store->price_stock_out_this_month > 0 ? $store->price_stock_out_this_month : 0;
            $store->barang_titip = $store->barang_titip > 0 ? $store->barang_titip : 0;
            $store->total_price_this_month = $store->total_price_this_month > 0 ? $store->total_price_this_month : 0;
            

            $store->date = Stock::select('created_at')->limit(1)->orderBy('created_at', 'desc')->first()->created_at;
        }
        // return $stores;

        return view('admin.report_all', compact('stores'));
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function reportApi(Request $request)
    {
        $store_code = $request->has('store') ? $request->store : \App\Store::first()->code;
        $date = $request->has('date') ? $request->date : today();
        $this_month = date('Y-m', strtotime($date));
        $last_month = date('Y-m', strtotime($date.'-1 month'));

        $stocks = Stock::select('*')->where('store_code', $store_code)->groupBy('jan_code');

        switch ($request->filter) {
            case 'per_day':
                $stocks = $stocks->whereDate('stock_datetime', 'like', date('Y-m-d', strtotime($date)).'%');
                break;
            case 'per_month':
                $stocks = $stocks->where('stock_datetime', 'like', date('Y-m', strtotime($date)).'%');
                break;
            case 'per_year':
                $stocks = $stocks->whereYear('stock_datetime', date('Y', strtotime($date)));
                break;
            default:
                $stocks = $stocks->where('stock_datetime', 'like', date('Y-m', strtotime($date)).'%');
        }

        $in_last_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                ->where('created_at', 'like', $last_month.'%')
                                ->where('arrow', 'in')
                                ->where('store_code', $store_code)
                                ->first()
                                ->total;

        $out_last_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                ->where('created_at', 'like', $last_month.'%')
                                ->where('arrow', 'out')
                                ->where('store_code', $store_code)
                                ->first()
                                ->total;

        $in_this_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                ->where('created_at', 'like', $this_month.'%')
                                ->where('arrow', 'in')
                                ->where('store_code', $store_code)
                                ->first()
                                ->total;

        $out_this_month = Stock::select(DB::raw("SUM(amount) AS total"))
                                ->where('created_at', 'like', $this_month.'%')
                                ->where('arrow', 'out')
                                ->where('store_code', $store_code)
                                ->first()
                                ->total;

        $total_last_month = $in_last_month - $out_last_month;
        $total_this_month = $total_last_month + $in_this_month - $out_this_month;

        $datatables = datatables()->of($stocks)->addIndexColumn()
                        ->addColumn('stock_in_this_month', function ($stock) use ($this_month) {
                            return Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('jan_code', $stock->jan_code)
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'in')
                                                ->first()
                                                ->total;
                        })->addColumn('stock_out_this_month', function ($stock) use ($this_month) {
                            return Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('jan_code', $stock->jan_code)
                                                ->where('created_at', 'like', $this_month.'%')
                                                ->where('arrow', 'out')
                                                ->first()
                                                ->total;
                        })->addColumn('stock_in_last_month', function ($stock) use ($last_month) {
                            return Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('jan_code', $stock->jan_code)
                                                ->where('created_at', 'like', $last_month.'%')
                                                ->where('arrow', 'in')
                                                ->first()
                                                ->total;
                        })->addColumn('stock_out_last_month', function ($stock) use ($last_month) {
                            return Stock::select(DB::raw("SUM(amount) AS total"))
                                                ->where('jan_code', $stock->jan_code)
                                                ->where('created_at', 'like', $last_month.'%')
                                                ->where('arrow', 'out')
                                                ->first()
                                                ->total;
                        })->addColumn('brand', function ($stock) {
                            return $stock->stock_master ? $stock->stock_master->brand : null;
                        })->addColumn('section', function ($stock) {
                            return $stock->stock_master ? $stock->stock_master->section : null;
                        })->addColumn('series', function ($stock) {
                            return $stock->stock_master ? $stock->stock_master->series : null;
                        })->addColumn('rim', function ($stock) {
                            return $stock->stock_master ? $stock->stock_master->rim : null;
                        })->addColumn('price', function ($stock) {
                            return $stock->stock_master ? $stock->stock_master->price : null;
                        })->addColumn('bs_amount', function ($stock) {
                            return $stock->bs_stock ? $stock->bs_stock->amount : 0;
                        })->addColumn('bs_titip', function ($stock) {
                            return $stock->bs_stock ? $stock->bs_stock->barang_titip : 0;
                        })->addColumn('memo', function ($stock) {
                            return $stock->bs_stock ? $stock->bs_stock->memo : null;
                        })->addColumn('stock_name', function ($stock) {
                            return $stock->bs_stock ? $stock->bs_stock->stock_name : null;
                        })->editColumn('stock_datetime', function ($stock) {
                            return date('Y年m月d日', strtotime($stock->stock_datetime));
                        })->with([
                            'total_last_month'=>$total_last_month ? $total_last_month : 0, 
                            'total_this_month'=>$total_this_month ? $total_this_month : 0, 
                            'in_this_month'=>$in_this_month ? $in_this_month : 0, 
                            'out_this_month'=>$out_this_month ? $out_this_month : 0
                        ]);

        return $datatables->make(true);
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function graphBarStore(Request $request)
    {
        $stocks = Stock::select('type as name', 'id')->groupBy('type')->get();

        foreach ($stocks as $stock) {
            $stock->type = 'bar';
            $stock->stack = 'Advertising';
            $stock->data = Stock::select(DB::raw("SUM(amount) as total"))
                                ->where('arrow', 'out')
                                ->where('type', $stock->name)
                                ->first()
                                ->total;
        }

        return $stocks;
    }

    /**
     * Show the application page.
     *
     * @return \Illuminate\Http\Response
     */
    public function graphPieStore() {
        $brand = StockMaster::select(DB::raw("SUM(stocks.amount) as value"), 'stock_masters.brand as name')
                                ->groupBy('stock_masters.brand')
                                ->join('stocks', 'stocks.jan_code', '=', 'stock_masters.jan_code')
                                ->where('stocks.arrow', 'out')
                                // ->whereMonth('stocks.stock_datetime', date('m'))
                                ->where('stocks.store_code', auth()->user()->store_code)
                                ->where('stock_masters.brand', '!=', null)
                                ->get();
        return $brand;
    }

}