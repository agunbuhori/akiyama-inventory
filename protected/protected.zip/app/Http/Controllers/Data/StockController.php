<?php

namespace App\Http\Controllers\Data;

use DB;
use App\Stock;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filter = $request->has('filter') ? $request->filter : 'per_month';
        $store_code = $request->store != 'undefined' ? $request->store : auth()->user()->store_code;
        $date = $request->has('date') ? $request->date : today();
        $arrow = $request->has('arrow') ? $request->arrow : 'in';

        $stocks = Stock::select('id', 'jan_code', 'type', 'amount', 'price', 'stock_datetime')
                            ->where('store_code', $store_code)
                            ->where('arrow', $arrow);

        switch ($filter) {
            case 'per_day':
                $stocks = $stocks->whereDate('stock_datetime', 'like', date('Y-m-d', strtotime($date)).'%');
                break;
            case 'per_month':
                $stocks = $stocks->where('stock_datetime', 'like', date('Y-m', strtotime($date)).'%');
                break;
            case 'per_year':
                $stocks = $stocks->whereYear('stock_datetime', date('Y', strtotime($date)));
                break;
            default:
                $stocks = $stocks->where('stock_datetime', 'like', $date.'%');
        }

        $totalAmount = Stock::select(DB::raw("SUM(amount) AS total"))
                                ->where('arrow', $arrow)
                                ->where('store_code', $store_code)
                                ->first();

        $totalAmount = $totalAmount->total ? $totalAmount->total : 0;

        $datatables = datatables()->of($stocks)->addIndexColumn()
        ->addColumn('receipt_number', function ($stock) {
            return $stock->bs_stock ? $stock->bs_stock->receipt_number : null;
        })->addColumn('version', function ($stock) {
            return $stock->stock_master ? $stock->stock_master->version : null;
        })->addColumn('stock_name', function ($stock) {
            return $stock->bs_stock ? $stock->bs_stock->stock_name : null;
        })->addColumn('brand', function ($stock) {
            return $stock->stock_master ? $stock->stock_master->brand : null;
        })->editColumn('price', function ($stock) {
            return $stock->stock_master ? currency($stock->stock_master->price,  'jp') : null;
        })->addColumn('total', function ($stock) use ($arrow) {
            return $stock->stock_master ? currency($stock->stock_master->price*$stock->amount,  'jp') : null;
        })->editColumn('stock_datetime', function ($stock) {
            return date('Y年m月d日', strtotime($stock->stock_datetime));
        })->with(['totalAmount' => $totalAmount]);

        return $datatables->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function show(Stock $stock)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function edit(Stock $stock)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Stock $stock)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function destroy(Stock $stock)
    {
        if (! request()->has('datas'))
            $stock->delete();
        else
            $stock->whereIn('id', request()->datas)->delete();
    }
}
