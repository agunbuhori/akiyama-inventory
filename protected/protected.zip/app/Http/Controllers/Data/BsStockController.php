<?php

namespace App\Http\Controllers\Data;

use App\BsStock;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BsStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $bsStocks = BsStock::select('id', 'jan_code', 'receipt_date', 'receipt_number', 'stock_name', 'barang_titip', 'amount', 'sell_price', 'basic_price', 'company_name', 'company_code', 'stock_code');

        $datatables = datatables()->of($bsStocks)->addIndexColumn()->addColumn('version', function($bsStock) {
            return $bsStock->stock_master ? $bsStock->stock_master->version : null;
        });

        return $datatables->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'company_code' => 'required',
            'receipt_date' => 'required',
            'receipt_number' => 'required',
            'stock_code' => 'required',
            'jan_code' => 'required',
            'stock_name' => 'required',
            'amount' => 'required',
            'sell_price' => 'required',
            'basic_price' => 'required',
        ]);

        $bsStock = new BsStock;

        $bsStock->company_code = $request->company_code;
        $bsStock->receipt_date = rtrim(str_replace(['年', '月', '日'], '-', $request->receipt_date), '-');
        $bsStock->receipt_number = $request->receipt_number;
        $bsStock->stock_code = $request->stock_code;
        $bsStock->jan_code = $request->jan_code;
        $bsStock->stock_name = $request->stock_name;
        $bsStock->amount = $request->amount;
        $bsStock->sell_price = $request->sell_price;
        $bsStock->basic_price = $request->basic_price;
        $bsStock->user_id = auth()->user()->id;

        $bsStock->save();

        return back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BsStock $bsStock)
    {
        $this->validate($request,[
            'company_code' => 'required',
            'receipt_date' => 'required',
            'receipt_number' => 'required',
            'stock_code' => 'required',
            'jan_code' => 'required',
            'stock_name' => 'required',
            'amount' => 'required',
            'sell_price' => 'required',
            'basic_price' => 'required',
        ]);

        $bsStock->company_code = $request->company_code;
        $bsStock->receipt_date = rtrim(str_replace(['年', '月', '日'], '-', $request->receipt_date), '-');
        $bsStock->receipt_number = $request->receipt_number;
        $bsStock->stock_code = $request->stock_code;
        $bsStock->jan_code = $request->jan_code;
        $bsStock->stock_name = $request->stock_name;
        $bsStock->amount = $request->amount;
        $bsStock->sell_price = $request->sell_price;
        $bsStock->basic_price = $request->basic_price;
        $bsStock->user_id = auth()->user()->id;

        $bsStock->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BsStock  $bsStock
     * @return \Illuminate\Http\Response
     */
    public function destroy(BsStock $bsStock)
    {
        if (! request()->has('datas'))
            $bsStock->delete();
        else
            $bsStock->whereIn('id', request()->datas)->delete();
    }
}
