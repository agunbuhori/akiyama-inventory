<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockMaster extends Model
{
    //
}
