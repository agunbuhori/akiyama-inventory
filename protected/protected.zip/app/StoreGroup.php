<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoreGroup extends Model
{
    //
}
